"""
evolve.py — THE LIFE-AND-DEATH BRAIN.

This is the piece your system was missing. You already record each strategy's
fitness (v2_arms: closed / wins / total_pnl) and store genomes with a family
tree (v2_arm_defs: params / gen / parent / alive / born_at / died_at). But
nothing ever DIES and nothing ever BREEDS automatically. This module does both:

  1. SCORE   every living arm.
  2. REAP    arms that have proven they lose money -> mark them dead.
  3. BREED   the survivors -> create mutated children (next generation).

It is deliberately CONSERVATIVE and defaults to DRY_RUN (it prints what it would
do and writes nothing) so you can watch it think before you let it touch your
live arena. Flip DRY_RUN=0 in .env when you trust it.

Fitness:
  * ENTRY arms  = blend of live expectancy (from v2_arms) and backtest
                  expectancy (from backtest.py over your historical launches).
  * EXIT arms   = live expectancy only (can't be backtested without price paths).
"""

import os
import time
import random
import string
from dotenv import load_dotenv

import db
from backtest import score_genome

load_dotenv()

# ---- tunables (override any of these in .env) -------------------------------
DRY_RUN        = os.environ.get("DRY_RUN", "1") == "1"   # default: don't write
MIN_CLOSED     = int(os.environ.get("MIN_CLOSED", "8"))  # trades before an arm can be judged/killed on live results
KILL_EXP       = float(os.environ.get("KILL_EXP", "-8")) # avg live pnl-per-trade below this = death candidate
MIN_ALIVE      = int(os.environ.get("MIN_ALIVE", "3"))   # never let a kind (entry/exit) drop below this many alive
MAX_ALIVE      = int(os.environ.get("MAX_ALIVE", "12"))  # cap population per kind; breed up to this
BREED_MIN_EXP  = float(os.environ.get("BREED_MIN_EXP", "0")) # only breed arms with fitness above this
BT_MIN_N       = int(os.environ.get("BT_MIN_N", "15"))   # min backtest sample to trust a backtest expectancy
LIVE_WEIGHT    = float(os.environ.get("LIVE_WEIGHT", "0.6")) # blend: 60% live, 40% backtest for entry arms
# ----------------------------------------------------------------------------

# Bounds so mutation can't produce nonsense. min/max per numeric param.
PARAM_BOUNDS = {
    "min_mcap":            (3000, 15000),
    "max_mcap":            (20000, 120000),
    "max_dev":             (1, 120),
    "min_buyers":          (1, 100),
    "min_social_score":    (0, 90),
    "min_views":           (0, 50000),
    "min_comm":            (0, 5000),
    "min_comments":        (0, 50),
    "max_top_holder":      (30, 95),
    "min_bs_ratio":        (1.0, 3.0),
    "min_gtrends":         (0, 100),
    "max_bot_pct":         (20, 100),
    "max_creator_launches":(0, 5),
    # exit params
    "activate":            (1.05, 2.5),
    "giveback":            (0.1, 0.6),
    "timeout_h":           (2, 24),
    "target":             (1.3, 5.0),
    "break_frac":         (0.005, 0.1),
}
INT_PARAMS = {"min_mcap", "max_mcap", "max_dev", "min_buyers", "min_social_score",
              "min_views", "min_comm", "min_comments", "max_top_holder",
              "min_gtrends", "max_bot_pct", "max_creator_launches", "timeout_h"}


def _log(msg):
    print(msg, flush=True)


# ---------------------------------------------------------------------------
# LOAD
# ---------------------------------------------------------------------------
def load_arms():
    """Join genome (v2_arm_defs) with live scoreboard (v2_arms)."""
    return db.query(
        """
        SELECT d.arm, d.kind, d.params, d.gen, d.parent, d.alive,
               COALESCE(a.closed,0) AS closed,
               COALESCE(a.wins,0)   AS wins,
               COALESCE(a.total_pnl,0)::float AS total_pnl
        FROM v2_arm_defs d
        LEFT JOIN v2_arms a ON a.arm = d.arm
        WHERE d.alive = true
        ORDER BY d.kind, d.arm
        """
    )


# ---------------------------------------------------------------------------
# SCORE
# ---------------------------------------------------------------------------
def fitness(arm):
    """
    Return (score, detail_string). Higher = fitter. Score is 'expectancy':
    average money made per trade, on the same pnl scale as total_pnl.
    """
    closed = arm["closed"]
    live_exp = arm["total_pnl"] / closed if closed else None

    if arm["kind"] == "exit":
        if live_exp is None:
            return (None, "exit arm, no closed trades yet")
        return (live_exp, f"live exp {live_exp:+.1f} over {closed} trades")

    # entry arm: blend live + backtest
    bt = score_genome(arm["params"] or {})
    bt_exp_pct = bt["expectancy"] * 100.0  # backtest expectancy is a fraction; scale toward pnl points
    bt_ok = bt["n"] >= BT_MIN_N

    if live_exp is not None and bt_ok:
        blended = LIVE_WEIGHT * live_exp + (1 - LIVE_WEIGHT) * bt_exp_pct
        return (blended, f"blend live {live_exp:+.1f}({closed}) + bt {bt_exp_pct:+.1f}"
                         f"(n={bt['n']},cov={bt['coverage']}) = {blended:+.1f}")
    if live_exp is not None:
        return (live_exp, f"live exp {live_exp:+.1f} over {closed} trades (bt sample too small)")
    if bt_ok:
        return (bt_exp_pct, f"backtest only {bt_exp_pct:+.1f} (n={bt['n']},cov={bt['coverage']})")
    return (None, f"not enough data (closed={closed}, bt_n={bt['n']})")


# ---------------------------------------------------------------------------
# REAP  (extinction of the feeble)
# ---------------------------------------------------------------------------
def reap(scored):
    """
    Kill arms that have PROVEN they lose money. Rules (all must hold):
      * has at least MIN_CLOSED closed live trades (we don't kill on a hunch)
      * live expectancy is below KILL_EXP
      * killing it won't drop its kind below MIN_ALIVE survivors
      * it isn't the single best arm of its kind
    """
    killed = []
    for kind in ("entry", "exit"):
        of_kind = [s for s in scored if s["kind"] == kind]
        alive_now = len(of_kind)
        # worst first
        of_kind_sorted = sorted(of_kind, key=lambda s: (s["score"] is None, s["score"]))
        best = max((s for s in of_kind if s["score"] is not None),
                   key=lambda s: s["score"], default=None)
        for s in of_kind_sorted:
            if alive_now <= MIN_ALIVE:
                break
            live_exp = s["total_pnl"] / s["closed"] if s["closed"] else None
            if s["closed"] < MIN_CLOSED or live_exp is None:
                continue
            if best and s["arm"] == best["arm"]:
                continue
            if live_exp < KILL_EXP:
                killed.append(s)
                alive_now -= 1
    return killed


def kill_arm(arm_name):
    db.execute("UPDATE v2_arm_defs SET alive=false, died_at=now() WHERE arm=%s", (arm_name,))
    db.execute("UPDATE v2_arms     SET alive=false, died_at=now() WHERE arm=%s", (arm_name,))


# ---------------------------------------------------------------------------
# BREED  (mutation of survivors)
# ---------------------------------------------------------------------------
def _mutate(params):
    """Return a mutated copy of a genome: jitter each numeric param within bounds."""
    child = dict(params)
    for k, v in list(child.items()):
        if k not in PARAM_BOUNDS or not isinstance(v, (int, float)):
            continue
        lo, hi = PARAM_BOUNDS[k]
        # jitter +/- up to 30%
        factor = 1.0 + random.uniform(-0.30, 0.30)
        nv = v * factor
        nv = max(lo, min(hi, nv))
        child[k] = int(round(nv)) if k in INT_PARAMS else round(nv, 3)
    # occasionally drop or add an optional constraint to explore new shapes
    optional = ["min_buyers", "min_social_score", "max_top_holder", "min_comments"]
    if random.random() < 0.25:
        present = [o for o in optional if o in child]
        absent = [o for o in optional if o not in child]
        if random.random() < 0.5 and present:
            child.pop(random.choice(present))
        elif absent:
            add = random.choice(absent)
            lo, hi = PARAM_BOUNDS[add]
            val = random.uniform(lo, hi)
            child[add] = int(round(val)) if add in INT_PARAMS else round(val, 3)
    return child


def _child_name(parent_name):
    base = parent_name.split("-")[0]
    suffix = "".join(random.choices(string.ascii_lowercase + string.digits, k=4))
    return f"{base}g-{suffix}"


def breed(scored):
    """Create mutated children of the fittest survivors, up to MAX_ALIVE per kind."""
    born = []
    for kind in ("entry", "exit"):
        of_kind = [s for s in scored if s["kind"] == kind and s["score"] is not None]
        alive_now = len([s for s in scored if s["kind"] == kind])
        parents = sorted(of_kind, key=lambda s: s["score"], reverse=True)
        parents = [p for p in parents if p["score"] > BREED_MIN_EXP]
        i = 0
        while alive_now < MAX_ALIVE and parents:
            parent = parents[i % len(parents)]
            child_params = _mutate(parent["params"] or {})
            child = {
                "arm": _child_name(parent["arm"]),
                "kind": kind,
                "params": child_params,
                "gen": (parent["gen"] or 1) + 1,
                "parent": parent["arm"],
            }
            born.append(child)
            alive_now += 1
            i += 1
            if i >= len(parents) * 3:  # each parent breeds at most ~3 this round
                break
    return born


def insert_child(child):
    import json
    db.execute(
        "INSERT INTO v2_arm_defs (arm, kind, params, gen, parent, alive, born_at) "
        "VALUES (%s,%s,%s,%s,%s,true,now())",
        (child["arm"], child["kind"], json.dumps(child["params"]),
         child["gen"], child["parent"]),
    )
    db.execute(
        "INSERT INTO v2_arms (arm, closed, wins, total_pnl, alive) "
        "VALUES (%s,0,0,0,true) ON CONFLICT (arm) DO NOTHING",
        (child["arm"],),
    )


# ---------------------------------------------------------------------------
# ONE GENERATION
# ---------------------------------------------------------------------------
def run_generation():
    mode = "DRY RUN (no writes)" if DRY_RUN else "LIVE (writing to Supabase)"
    _log(f"\n{'='*66}\n  EVOLUTION — {mode}\n{'='*66}")

    arms = load_arms()
    scored = []
    for a in arms:
        s, detail = fitness(a)
        a = dict(a); a["score"] = s; a["detail"] = detail
        scored.append(a)

    # scoreboard
    _log("\n  ARMS (fittest first per kind):")
    for kind in ("entry", "exit"):
        _log(f"\n   {kind.upper()}:")
        rows = sorted([s for s in scored if s["kind"] == kind],
                      key=lambda s: (s["score"] is None, -(s["score"] or 0)))
        for s in rows:
            sc = f"{s['score']:+.1f}" if s["score"] is not None else "  n/a"
            _log(f"     {sc:>7}  {s['arm']:<18} gen{s['gen']}  ({s['detail']})")

    # reap
    killed = reap(scored)
    _log("\n  REAP (extinction of the feeble):")
    if not killed:
        _log("     nothing dies this round (nobody has both enough trades AND bad enough numbers)")
    for k in killed:
        live_exp = k["total_pnl"] / k["closed"]
        _log(f"     ☠  KILL {k['arm']:<18} live exp {live_exp:+.1f} over {k['closed']} trades")
        if not DRY_RUN:
            kill_arm(k["arm"])

    # remove killed from the pool before breeding
    killed_names = {k["arm"] for k in killed}
    survivors = [s for s in scored if s["arm"] not in killed_names]

    # breed
    born = breed(survivors)
    _log("\n  BREED (mutated children of survivors):")
    if not born:
        _log("     no breeding (population full, or no survivor is fit enough yet)")
    for c in born:
        _log(f"     ✚  BORN {c['arm']:<18} gen{c['gen']}  parent={c['parent']}  {c['params']}")
        if not DRY_RUN:
            insert_child(c)

    _log(f"\n  Summary: {len(scored)} alive -> {len(killed)} killed, {len(born)} born.\n")
    if not DRY_RUN:
        db.set_config("v2_evolver_beat", time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()))
    return {"alive": len(scored), "killed": len(killed), "born": len(born)}


if __name__ == "__main__":
    run_generation()
