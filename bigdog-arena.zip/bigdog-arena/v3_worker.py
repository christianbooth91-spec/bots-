"""
v3_worker.py — the MIGRATION-ZONE bot (completely separate from the v2 arena).

Strategy (validated by preflight on your own data):
  Of coins that reach 40k, 72% continue to 50k, 54% to 60k, only 33% do a full 2x.
  So this bot ENTERS at >=40k and targets a SMALL move (+25-50%), not a 2x.

It is self-contained: it reads the v3_* tables + your existing live_launches /
v2_snapshots for candidates and the runner-fingerprint signals, and it uses the
FREE DexScreener API for live market cap to manage entries and exits. No key needed.

SAFETY: starts in DRY_RUN (prints, writes nothing) AND only acts when bot_config
v3_arena_on='1'. Flip both when you've watched it and trust it.

  python v3_worker.py            # loop
  python v3_worker.py --once     # one cycle

Reads its own money from v3_bank (latest cash). Stake = bot_config.v3_stake_usd ($200).
"""

import os, sys, time, json, traceback, urllib.request
from dotenv import load_dotenv
import db

load_dotenv()
DRY_RUN   = os.environ.get("DRY_RUN", "1") == "1"
EVERY_SEC = int(os.environ.get("V3_POLL_SEC", "60"))
FEES      = float(os.environ.get("V3_FEES", "0.06"))   # round-trip friction estimate


def cfg(k, d):
    v = db.get_config(k, None)
    return v if v is not None else d


def dexscreener_mcap(mint):
    """Live market cap for a Solana mint via the free DexScreener API. None on failure."""
    try:
        url = f"https://api.dexscreener.com/latest/dex/tokens/{mint}"
        req = urllib.request.Request(url, headers={"User-Agent": "bigdog/1.0"})
        data = json.loads(urllib.request.urlopen(req, timeout=12).read())
        pairs = [p for p in (data.get("pairs") or []) if p.get("chainId") == "solana"]
        if not pairs:
            return None
        best = max(pairs, key=lambda p: (p.get("liquidity") or {}).get("usd", 0) or 0)
        return best.get("marketCap") or best.get("fdv")
    except Exception:
        return None


# ---------------- candidates ----------------
def find_candidates():
    """
    Coins currently sitting in the 40k-55k window, still active, with the runner
    signals we have (from the 6k snapshot as a proxy), not already open in v3.
    """
    lo = float(cfg("v3_min_entry_mcap", 40000)); hi = lo * 1.375  # ~40k-55k
    return db.query(
        """
        SELECT l.mint, l.name, l.mcap_last_seen::float mcap,
               s.top_holder_pct, s.unique_buyers, s.buy_sell_ratio, COALESCE(s.dev_buy_sol,0) dev
        FROM live_launches l
        JOIN v2_snapshots s ON s.mint = l.mint
        WHERE l.mcap_last_seen >= %s AND l.mcap_last_seen <= %s
          AND l.last_seen_live > now() - interval '10 minutes'
          AND NOT COALESCE(l.mcap_suspect,false)
          AND l.mint NOT IN (SELECT mint FROM v3_paper WHERE open)
        ORDER BY l.mcap_last_seen
        """, (lo, hi))


def alive_entry_arms():
    return db.query("SELECT d.arm,d.params FROM v3_arm_defs d JOIN v3_arms a ON a.arm=d.arm WHERE d.alive AND d.kind='entry'")


def arm_matches(params, c):
    p = params
    if "max_top_holder" in p and c["top_holder_pct"] is not None and c["top_holder_pct"] > p["max_top_holder"]:
        return False
    if "min_buyers" in p and c["unique_buyers"] is not None and c["unique_buyers"] < p["min_buyers"]:
        return False
    if "min_bs_ratio" in p and c["buy_sell_ratio"] is not None and c["buy_sell_ratio"] < p["min_bs_ratio"]:
        return False
    if "max_dev" in p and c["dev"] and c["dev"] > p["max_dev"]:
        return False
    return True


def bank():
    r = db.query("SELECT cash FROM v3_bank ORDER BY id DESC LIMIT 1")
    return float(r[0]["cash"]) if r else 0.0


def open_entries(log):
    stake = float(cfg("v3_stake_usd", 200))
    arms = alive_entry_arms()
    if not arms:
        return
    for c in find_candidates():
        for a in arms:
            if not arm_matches(a["params"] or {}, c):
                continue
            if bank() < stake:
                log("  bank below stake — skipping new entries"); return
            pin = (a["params"] or {}).get("pin_exit", "X-scalp50")
            log(f"  ENTER {c['name'][:20]:<20} @ {c['mcap']:.0f}  via {a['arm']} -> {pin}  ${stake}")
            if not DRY_RUN:
                db.execute(
                    "INSERT INTO v3_paper(mint,name,entry_mcap,arm_entry,arm_exit,open,high_mcap,stake_usd) "
                    "VALUES(%s,%s,%s,%s,%s,true,%s,%s)",
                    (c["mint"], c["name"], c["mcap"], a["arm"], pin, c["mcap"], stake))
                db.execute("INSERT INTO v3_bank(cash,event) VALUES((SELECT cash FROM v3_bank ORDER BY id DESC LIMIT 1)-%s,%s)",
                           (stake, f"OPEN {c['name'][:18]} -${stake:.0f}"))
            break  # one arm per coin


def exit_rule(params, entry, high, cur, age_min):
    """Return (should_exit, reason) for an exit arm given price multiples."""
    p = params; mult = cur / entry if entry else 1.0; hi_mult = high / entry if entry else 1.0
    typ = p.get("type", "momentum")
    if typ in ("momentum", "ladder"):
        if mult >= p.get("target", 1.3):
            return True, f"target {p.get('target')}x"
        if mult <= p.get("stop", 0.85):
            return True, f"stop {int((1-p.get('stop',0.85))*100)}%"
        if age_min >= p.get("timeout_min", 30):
            return True, f"{p.get('timeout_min',30)}m timeout"
    if typ == "trail":
        act = p.get("activate", 1.2); gb = p.get("giveback", 0.25)
        if hi_mult >= act and mult <= hi_mult * (1 - gb):
            return True, f"trail{int(gb*100)} (hi {hi_mult:.1f}x)"
        if age_min >= p.get("timeout_h", 6) * 60:
            return True, "timeout"
    return False, ""


def manage_open(log):
    rows = db.query("SELECT p.id,p.mint,p.name,p.entry_mcap::float e,p.high_mcap::float hi,p.arm_exit,p.stake_usd::float stake,"
                    "EXTRACT(EPOCH FROM (now()-p.entered_at))/60 age FROM v3_paper p WHERE p.open")
    defs = {d["arm"]: d["params"] for d in db.query("SELECT arm,params FROM v3_arm_defs WHERE kind='exit'")}
    for r in rows:
        cur = dexscreener_mcap(r["mint"])
        if cur is None:
            continue
        high = max(r["hi"] or r["e"], cur)
        params = defs.get(r["arm_exit"], {"type": "momentum", "target": 1.3, "stop": 0.85, "timeout_min": 30})
        go, reason = exit_rule(params, r["e"], high, cur, r["age"])
        if not DRY_RUN:
            db.execute("UPDATE v3_paper SET high_mcap=%s WHERE id=%s", (high, r["id"]))
        if go:
            gross = cur / r["e"] - 1.0
            pnl = round((gross - FEES) * 100, 1)
            proceeds = r["stake"] * (1 + gross - FEES)
            log(f"  EXIT  {r['name'][:20]:<20} {reason:<16} pnl {pnl:+.1f}%")
            if not DRY_RUN:
                db.execute("UPDATE v3_paper SET open=false,exit_mcap=%s,exited_at=now(),exit_reason=%s,pnl_pct=%s WHERE id=%s",
                           (cur, reason, pnl, r["id"]))
                db.execute("INSERT INTO v3_bank(cash,event) VALUES((SELECT cash FROM v3_bank ORDER BY id DESC LIMIT 1)+%s,%s)",
                           (proceeds, f"CLOSE {r['name'][:16]} {pnl:+.0f}%"))
                db.execute("UPDATE v3_arms SET closed=closed+1, wins=wins+%s, total_pnl=total_pnl+%s WHERE arm="
                           "(SELECT arm_entry FROM v3_paper WHERE id=%s)",
                           (1 if pnl > 0 else 0, pnl, r["id"]))


def cycle():
    mode = "DRY_RUN" if DRY_RUN else "LIVE"
    on = str(cfg("v3_arena_on", "0")) == "1"
    print(f"\n[v3] {'='*50}\n[v3] migration-zone cycle — {mode} — arena_on={on} — bank ${bank():.0f}")
    if not on:
        print("[v3] v3_arena_on != 1 -> managing existing positions only, no new entries")
    manage_open(print)
    if on:
        open_entries(print)
    if not DRY_RUN:
        db.set_config("v3_worker_beat", time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()))


def main():
    once = "--once" in sys.argv
    print(f"[v3] migration-zone worker starting. poll={EVERY_SEC}s {'(once)' if once else ''}")
    while True:
        try:
            cycle()
        except Exception:
            print("[v3] cycle failed:"); traceback.print_exc()
        if once:
            break
        time.sleep(EVERY_SEC)


if __name__ == "__main__":
    main()
