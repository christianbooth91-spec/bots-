"""
db.py — one small Postgres connection helper for the whole arena.

We talk to your Supabase database directly over Postgres (not the REST API)
because the evolution engine does real analytics over thousands of rows and a
direct connection is faster and simpler.

You need ONE environment variable: DATABASE_URL
Get it from: Supabase dashboard -> your project -> "Connect" button ->
"Connection string" -> "Transaction pooler" (or Session). It looks like:
  postgresql://postgres.cvicypryecnxvwqczgtg:YOUR-PASSWORD@aws-...pooler.supabase.com:6543/postgres
Put it in a file called .env next to these scripts (see .env.example).
"""

import os
import contextlib
import psycopg2
import psycopg2.extras
from dotenv import load_dotenv

load_dotenv()

DATABASE_URL = os.environ.get("DATABASE_URL", "").strip()


def _require_url():
    if not DATABASE_URL:
        raise SystemExit(
            "DATABASE_URL is not set. Copy .env.example to .env and paste your "
            "Supabase connection string into it. See db.py for where to find it."
        )


@contextlib.contextmanager
def connect():
    """Yield a live connection. Commits on success, rolls back on error."""
    _require_url()
    conn = psycopg2.connect(DATABASE_URL)
    try:
        yield conn
        conn.commit()
    except Exception:
        conn.rollback()
        raise
    finally:
        conn.close()


def query(sql, params=None):
    """Run a SELECT, return list of dict rows."""
    with connect() as conn:
        with conn.cursor(cursor_factory=psycopg2.extras.RealDictCursor) as cur:
            cur.execute(sql, params or ())
            return [dict(r) for r in cur.fetchall()]


def execute(sql, params=None):
    """Run an INSERT/UPDATE/DELETE. Returns affected row count."""
    with connect() as conn:
        with conn.cursor() as cur:
            cur.execute(sql, params or ())
            return cur.rowcount


def get_config(key, default=None):
    rows = query("SELECT v FROM bot_config WHERE k=%s", (key,))
    return rows[0]["v"] if rows else default


def set_config(key, value):
    execute(
        "INSERT INTO bot_config (k, v) VALUES (%s, %s) "
        "ON CONFLICT (k) DO UPDATE SET v = EXCLUDED.v",
        (key, str(value)),
    )
