# BigDog Arena — the evolution engine

The natural-selection brain for your Solana launch-trading arena. Your existing
pipeline collects the data and runs the live paper trades. **This** process adds
the part that was missing: it makes strategies live and **die**.

Every generation it:

1. **Scores** every living arm (strategy). Entry arms are judged on a blend of
   your live paper results *and* a backtest over your ~390 historical launches
   with known outcomes. Exit arms are judged on live results only.
2. **Reaps** — kills arms that have proven, over enough real trades, that they
   lose money. They get `alive=false` and a `died_at` timestamp. Extinction.
3. **Breeds** — the fittest survivors spawn mutated children (their genome with
   the numbers jittered, sometimes a constraint added or dropped). New
   generation, `gen = parent.gen + 1`, with the parent recorded. Evolution.

It touches only your `v2_arm_defs`, `v2_arms`, and `bot_config` tables.

## Files
- `arena.py` — the runner loop (this is what you start / deploy)
- `evolve.py` — the reap + breed engine
- `backtest.py` — scores an entry genome against historical outcomes
- `db.py` — Supabase Postgres connection
- `.env.example` — copy to `.env` and fill in

## The safety switch
It starts in **DRY_RUN mode**: it prints exactly what it would kill and breed
but writes nothing. Watch a few generations, make sure the decisions look sane,
then set `DRY_RUN=0` to let it act for real.

## Run locally (to watch it think)
```bash
pip install -r requirements.txt
cp .env.example .env        # then paste your DATABASE_URL into .env
python arena.py --once      # one generation, then exits
```

## Run on Railway (recommended — always on)
1. New project → deploy this repo.
2. Add Variables: `DATABASE_URL` (your Supabase connection string), `DRY_RUN=1`.
3. It runs as a worker (`Procfile`). Watch the deploy logs for the generation
   report. When happy, set `DRY_RUN=0` and redeploy.

## Tuning
All knobs live in `.env` / Railway Variables — see `.env.example` for what each
one does. The important early ones: `MIN_CLOSED` (how much proof before an arm
can be killed) and `KILL_EXP` (how bad it has to be).

## Honest limits
- Backtests only apply to **entry** arms, and only for params that map to columns
  you store. A genome can be partly "unscored" — don't over-trust a great
  backtest if coverage is low. Live results are always the real judge.
- `peak_x_usd` is the ceiling a coin hit, not what you capture. The backtest
  models a realistic 2x-target / stop exit with fees, not selling the top.
- Keep it in paper mode until evolved survivors show positive expectancy over a
  few hundred real trades. This tool's biggest value is killing your losers
  before they cost you real money.
```
