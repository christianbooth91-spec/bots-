"""
backtest.py — score an ENTRY genome against your real historical outcomes.

WHY THIS EXISTS
Your live paper trades are the ground truth, but they're slow: you only get a
few closed trades a day, so an arm needs weeks to prove itself live. The
backtester lets a new genome be judged in seconds against the ~390 launches in
`live_launches` that already have a known outcome (entry mcap + peak multiple).
That's what lets evolution move fast instead of waiting for reality.

HONESTY NOTES (read these — they matter for not fooling yourself):
  * We can only backtest ENTRY arms here. Exit arms (trail/momentum/free) need a
    dense minute-by-minute price feed to simulate, and your price_path table only
    has ~1 point per coin. So exit arms are evolved from LIVE results only.
  * `peak_x_usd` is the BEST the coin ever traded — the ceiling, not what you'd
    capture. We therefore model a realistic exit (sell at a target, or dump at a
    stop) instead of pretending you sell the exact top.
  * Some genome params (min_buyers, max_top_holder, min_bs_ratio, etc.) are not
    present as columns we can filter on, so the backtest simply can't enforce
    them and reports them as 'unscored'. Don't read a great backtest as proof if
    most of the genome was unscored.
"""

from db import query

# --- exit model used to turn "peak multiple" into a realistic captured return ---
# Assume: buy at entry, sell if it reaches TARGET_X, otherwise dump at STOP loss.
# FEES covers swap fee + slippage + priority fees, round trip, as a fraction.
TARGET_X = 2.0        # take-profit target (2x)
STOP_LOSS = 0.35      # if it never hits target, assume you lose 35% getting out
FEES = 0.06           # 6% round-trip friction (generous for pump.fun-style coins)

# Which genome params we can actually evaluate against columns we have:
SCOREABLE = {"min_mcap", "max_mcap", "max_dev", "min_social_score", "min_views",
             "min_comm", "min_comments"}


def _load_universe():
    """All launches with a known outcome, joined to their latest grade."""
    return query(
        """
        SELECT l.mint,
               l.entry_mcap_usd::float           AS entry_mcap,
               l.peak_x_usd::float               AS peak_x,
               l.hit_2x                          AS hit_2x,
               COALESCE(l.dev_buy_sol,0)::float  AS dev_buy_sol,
               l.watched_creator                 AS watched_creator,
               g.score::float                    AS score,
               g.eff_views::float                AS eff_views,
               g.comm_members::float             AS comm_members,
               g.post_comments::float            AS post_comments
        FROM live_launches l
        LEFT JOIN LATERAL (
            SELECT score, eff_views, comm_members, post_comments
            FROM coin_grades cg
            WHERE cg.mint = l.mint
            ORDER BY graded_at DESC
            LIMIT 1
        ) g ON true
        WHERE l.entry_mcap_usd IS NOT NULL
          AND l.peak_x_usd IS NOT NULL
          AND l.entry_mcap_usd > 0
        """
    )


# module-level cache so we don't re-pull the universe for every genome
_UNIVERSE = None


def universe():
    global _UNIVERSE
    if _UNIVERSE is None:
        _UNIVERSE = _load_universe()
    return _UNIVERSE


def _passes(row, p):
    """Does this launch pass the genome's ENTRY filter (for the params we can check)?"""
    if "min_mcap" in p and row["entry_mcap"] < p["min_mcap"]:
        return False
    if "max_mcap" in p and row["entry_mcap"] > p["max_mcap"]:
        return False
    if "max_dev" in p and row["dev_buy_sol"] > p["max_dev"]:
        return False
    if "min_social_score" in p:
        if row["score"] is None or row["score"] < p["min_social_score"]:
            return False
    if "min_views" in p:
        if row["eff_views"] is None or row["eff_views"] < p["min_views"]:
            return False
    if "min_comm" in p:
        if row["comm_members"] is None or row["comm_members"] < p["min_comm"]:
            return False
    if "min_comments" in p:
        if row["post_comments"] is None or row["post_comments"] < p["min_comments"]:
            return False
    return True


def _captured_return(row):
    """Realistic per-trade return fraction using the target/stop exit model."""
    if row["hit_2x"] or (row["peak_x"] is not None and row["peak_x"] >= TARGET_X):
        gross = TARGET_X - 1.0          # e.g. +1.00 (=+100%) at a 2x target
    else:
        # never reached target: assume we bail near the stop
        gross = -STOP_LOSS
    return gross - FEES


def score_genome(params):
    """
    Score one ENTRY genome. Returns a dict:
      n            : launches that passed the filter (the sample size)
      hit2x_rate   : fraction of passers that hit 2x
      expectancy   : average modeled captured return per trade (THE fitness number)
      avg_peak_x   : average peak multiple of passers (context only, not capturable)
      coverage     : fraction of this genome's params the backtest could actually enforce
      unscored     : list of params that could not be enforced
    """
    rows = universe()
    passers = [r for r in rows if _passes(r, params)]
    n = len(passers)

    unscored = [k for k in params.keys() if k not in SCOREABLE]
    total_params = max(1, len(params))
    coverage = 1.0 - (len(unscored) / total_params)

    if n == 0:
        return {"n": 0, "hit2x_rate": 0.0, "expectancy": 0.0,
                "avg_peak_x": 0.0, "coverage": round(coverage, 2),
                "unscored": unscored}

    hits = sum(1 for r in passers if r["hit_2x"])
    exp = sum(_captured_return(r) for r in passers) / n
    avg_peak = sum(r["peak_x"] for r in passers) / n

    return {
        "n": n,
        "hit2x_rate": round(hits / n, 3),
        "expectancy": round(exp, 4),
        "avg_peak_x": round(avg_peak, 2),
        "coverage": round(coverage, 2),
        "unscored": unscored,
    }


if __name__ == "__main__":
    # quick manual check: score a couple of your real gen-1 entry arms
    demo = {
        "E3-clean6k": {"min_mcap": 5000, "max_mcap": 60000, "max_dev": 80},
        "E6-social65": {"min_mcap": 5000, "max_mcap": 80000, "max_dev": 80,
                        "min_social_score": 35},
    }
    print(f"Historical universe: {len(universe())} launches with known outcomes\n")
    for name, p in demo.items():
        s = score_genome(p)
        print(f"{name}: {s}")
