# DEPLOYMENT HANDOFF — "BigDog Arena" evolutionary trading engine

**Paste this entire file into a Claude Code / Cowork chat that is connected to GitHub, Railway, and Supabase.** It contains everything needed to finish the deployment: the mission, all the code, the real config values, what has already been done, and the exact remaining steps with verification.

---

## 0. YOUR ROLE (read first)

You are finishing a deployment that another Claude session set up. Do **exactly** the steps in section 6, in order. Do not redesign the code — it is complete and has been validated against the live database. Your job is to (a) put the code in a GitHub repo, (b) deploy it to the Railway project that already exists, (c) verify it connects and runs in safe DRY_RUN mode, then (d) report back so the owner can flip it live.

If any step fails, stop and report the exact error rather than improvising a different architecture.

---

## 1. WHAT THIS IS

The owner (Christian) runs a Solana meme-coin launch pipeline. It already collects launches, grades them on social signals, tracks price paths and outcomes, and runs **live paper trades** using a set of strategy "arms" (entry arms `E*` and exit arms `T*`). Each arm's genome and fitness are stored in Supabase:

- `v2_arm_defs(arm, kind, params jsonb, gen, parent, alive, born_at, died_at)` — the **genomes** (family tree).
- `v2_arms(arm, closed, wins, total_pnl, alive, died_at)` — the **live scoreboard**.
- `v2_paper(...)` — the live paper trades (source of truth for fitness).
- `bot_config(k, v)` — key/value settings; also used for heartbeats and the halt flag.
- `live_launches`, `coin_grades`, `coin_outcome`, `price_path` — historical data for backtesting.

**The problem being solved:** arms record fitness but nothing ever *dies* and nothing *breeds automatically*. Two arms are bleeding money in paper (`E3-clean6k` ~ −24/trade over 15, `T3-momentum` ~ −32/trade over 14) yet stay `alive`. This engine adds the missing natural selection: **score → reap losers → breed mutated survivors**, on a schedule, forever — plus real-world guardrails (honeypot/rug/fake-volume blocks and a portfolio kill-switch).

It is a **separate, always-on worker**. It only reads/writes `v2_arm_defs`, `v2_arms`, and `bot_config`. It does not place trades itself — the owner's existing worker does that.

---

## 2. CONFIG VALUES (real — use these exactly)

- **Supabase project ref:** `cvicypryecnxvwqczgtg` (region ap-southeast-1, name "study-engin")
- **DATABASE_URL** (shared pooler, password percent-encoded — the raw password contains `& % / +`):
  ```
  postgresql://postgres.cvicypryecnxvwqczgtg:i_2%26X5B%25%2F%2BC_iGT@aws-0-ap-southeast-1.pooler.supabase.com:5432/postgres
  ```
  ⚠️ This is a **live secret**. Set it only as a private Railway variable. Never print it in logs or commit it to git. (Owner should rotate this password after go-live as good hygiene.)
- **GitHub owner:** `christianbooth91-spec`  → target repo: `christianbooth91-spec/bigdog-arena`
- **Railway project (ALREADY CREATED):**
  - projectId: `13659875-c684-409d-9ca7-23e0b0d9022d`
  - environmentId (production): `b80c5d75-25b5-4b9b-b6de-8b9b58da6ca4`
  - These three variables are **already set** on that environment: `DATABASE_URL`, `DRY_RUN=1`, `EVOLVE_EVERY_MIN=60`. (Confirm they exist; re-set if missing.)
  - If for some reason that project is not accessible, create a new project named `bigdog-arena` and set the variables yourself.

---

## 3. THE CODE (create these files exactly)

Create a repo with these files at the root. **Do not commit `.env`.**

### `db.py`
```python
"""
db.py — one small Postgres connection helper for the whole arena.

We talk to Supabase directly over Postgres (not the REST API) because the
evolution engine does real analytics over thousands of rows. Needs ONE env var:
DATABASE_URL (Supabase -> Connect -> Transaction/Session pooler string).
"""

import os
import contextlib
import psycopg2
import psycopg2.extras
from dotenv import load_dotenv

load_dotenv()

DATABASE_URL = os.environ.get("DATABASE_URL", "").strip()


def _require_url():
    if not DATABASE_URL:
        raise SystemExit(
            "DATABASE_URL is not set. Copy .env.example to .env and paste your "
            "Supabase connection string into it. See db.py for where to find it."
        )


@contextlib.contextmanager
def connect():
    """Yield a live connection. Commits on success, rolls back on error."""
    _require_url()
    conn = psycopg2.connect(DATABASE_URL)
    try:
        yield conn
        conn.commit()
    except Exception:
        conn.rollback()
        raise
    finally:
        conn.close()


def query(sql, params=None):
    """Run a SELECT, return list of dict rows."""
    with connect() as conn:
        with conn.cursor(cursor_factory=psycopg2.extras.RealDictCursor) as cur:
            cur.execute(sql, params or ())
            return [dict(r) for r in cur.fetchall()]


def execute(sql, params=None):
    """Run an INSERT/UPDATE/DELETE. Returns affected row count."""
    with connect() as conn:
        with conn.cursor() as cur:
            cur.execute(sql, params or ())
            return cur.rowcount


def get_config(key, default=None):
    rows = query("SELECT v FROM bot_config WHERE k=%s", (key,))
    return rows[0]["v"] if rows else default


def set_config(key, value):
    execute(
        "INSERT INTO bot_config (k, v) VALUES (%s, %s) "
        "ON CONFLICT (k) DO UPDATE SET v = EXCLUDED.v",
        (key, str(value)),
    )
```

### `backtest.py`
```python
"""
backtest.py — score an ENTRY genome against real historical outcomes.

Judges a genome in seconds against the ~390 launches in live_launches that have
a known outcome (entry mcap + peak multiple), so evolution isn't gated on slow
live trades.

HONESTY NOTES:
  * Only ENTRY arms can be backtested. Exit arms need a dense price feed
    (price_path has ~1 point/coin) so they evolve from LIVE results only.
  * peak_x_usd is the ceiling a coin hit, not what you capture — we model a
    realistic 2x-target / stop exit with fees instead of selling the top.
  * Params not present as columns (min_buyers, max_top_holder, ...) are reported
    'unscored'. Don't trust a great backtest with low coverage.
"""

from db import query

TARGET_X = 2.0        # take-profit target (2x)
STOP_LOSS = 0.35      # loss taken if target never hit
FEES = 0.06           # 6% round-trip friction (generous for pump.fun coins)

SCOREABLE = {"min_mcap", "max_mcap", "max_dev", "min_social_score", "min_views",
             "min_comm", "min_comments"}


def _load_universe():
    return query(
        """
        SELECT l.mint,
               l.entry_mcap_usd::float           AS entry_mcap,
               l.peak_x_usd::float               AS peak_x,
               l.hit_2x                          AS hit_2x,
               COALESCE(l.dev_buy_sol,0)::float  AS dev_buy_sol,
               l.watched_creator                 AS watched_creator,
               g.score::float                    AS score,
               g.eff_views::float                AS eff_views,
               g.comm_members::float             AS comm_members,
               g.post_comments::float            AS post_comments
        FROM live_launches l
        LEFT JOIN LATERAL (
            SELECT score, eff_views, comm_members, post_comments
            FROM coin_grades cg
            WHERE cg.mint = l.mint
            ORDER BY graded_at DESC
            LIMIT 1
        ) g ON true
        WHERE l.entry_mcap_usd IS NOT NULL
          AND l.peak_x_usd IS NOT NULL
          AND l.entry_mcap_usd > 0
        """
    )


_UNIVERSE = None


def universe():
    global _UNIVERSE
    if _UNIVERSE is None:
        _UNIVERSE = _load_universe()
    return _UNIVERSE


def _passes(row, p):
    if "min_mcap" in p and row["entry_mcap"] < p["min_mcap"]:
        return False
    if "max_mcap" in p and row["entry_mcap"] > p["max_mcap"]:
        return False
    if "max_dev" in p and row["dev_buy_sol"] > p["max_dev"]:
        return False
    if "min_social_score" in p:
        if row["score"] is None or row["score"] < p["min_social_score"]:
            return False
    if "min_views" in p:
        if row["eff_views"] is None or row["eff_views"] < p["min_views"]:
            return False
    if "min_comm" in p:
        if row["comm_members"] is None or row["comm_members"] < p["min_comm"]:
            return False
    if "min_comments" in p:
        if row["post_comments"] is None or row["post_comments"] < p["min_comments"]:
            return False
    return True


def _captured_return(row):
    if row["hit_2x"] or (row["peak_x"] is not None and row["peak_x"] >= TARGET_X):
        gross = TARGET_X - 1.0
    else:
        gross = -STOP_LOSS
    return gross - FEES


def score_genome(params):
    rows = universe()
    passers = [r for r in rows if _passes(r, params)]
    n = len(passers)
    unscored = [k for k in params.keys() if k not in SCOREABLE]
    coverage = 1.0 - (len(unscored) / max(1, len(params)))
    if n == 0:
        return {"n": 0, "hit2x_rate": 0.0, "expectancy": 0.0,
                "avg_peak_x": 0.0, "coverage": round(coverage, 2),
                "unscored": unscored}
    hits = sum(1 for r in passers if r["hit_2x"])
    exp = sum(_captured_return(r) for r in passers) / n
    avg_peak = sum(r["peak_x"] for r in passers) / n
    return {"n": n, "hit2x_rate": round(hits / n, 3), "expectancy": round(exp, 4),
            "avg_peak_x": round(avg_peak, 2), "coverage": round(coverage, 2),
            "unscored": unscored}


if __name__ == "__main__":
    demo = {
        "E3-clean6k": {"min_mcap": 5000, "max_mcap": 60000, "max_dev": 80},
        "E6-social65": {"min_mcap": 5000, "max_mcap": 80000, "max_dev": 80,
                        "min_social_score": 35},
    }
    print(f"Historical universe: {len(universe())} launches with known outcomes\n")
    for name, p in demo.items():
        print(f"{name}: {score_genome(p)}")
```

### `evolve.py`
```python
"""
evolve.py — THE LIFE-AND-DEATH BRAIN.

  1. SCORE   every living arm.
  2. REAP    arms that have proven they lose money -> mark them dead.
  3. BREED   the survivors -> mutated children (next generation).

Conservative, and DRY_RUN by default (prints, writes nothing). Set DRY_RUN=0 to act.
Fitness: ENTRY = blend of live expectancy + backtest; EXIT = live only.
"""

import os
import time
import random
import string
from dotenv import load_dotenv

import db
from backtest import score_genome

load_dotenv()

DRY_RUN        = os.environ.get("DRY_RUN", "1") == "1"
MIN_CLOSED     = int(os.environ.get("MIN_CLOSED", "8"))
KILL_EXP       = float(os.environ.get("KILL_EXP", "-8"))
MIN_ALIVE      = int(os.environ.get("MIN_ALIVE", "3"))
MAX_ALIVE      = int(os.environ.get("MAX_ALIVE", "12"))
BREED_MIN_EXP  = float(os.environ.get("BREED_MIN_EXP", "0"))
BT_MIN_N       = int(os.environ.get("BT_MIN_N", "15"))
LIVE_WEIGHT    = float(os.environ.get("LIVE_WEIGHT", "0.6"))

PARAM_BOUNDS = {
    "min_mcap": (3000, 15000), "max_mcap": (20000, 120000), "max_dev": (1, 120),
    "min_buyers": (1, 100), "min_social_score": (0, 90), "min_views": (0, 50000),
    "min_comm": (0, 5000), "min_comments": (0, 50), "max_top_holder": (30, 95),
    "min_bs_ratio": (1.0, 3.0), "min_gtrends": (0, 100), "max_bot_pct": (20, 100),
    "max_creator_launches": (0, 5),
    "activate": (1.05, 2.5), "giveback": (0.1, 0.6), "timeout_h": (2, 24),
    "target": (1.3, 5.0), "break_frac": (0.005, 0.1),
}
INT_PARAMS = {"min_mcap", "max_mcap", "max_dev", "min_buyers", "min_social_score",
              "min_views", "min_comm", "min_comments", "max_top_holder",
              "min_gtrends", "max_bot_pct", "max_creator_launches", "timeout_h"}


def _log(msg):
    print(msg, flush=True)


def load_arms():
    return db.query(
        """
        SELECT d.arm, d.kind, d.params, d.gen, d.parent, d.alive,
               COALESCE(a.closed,0) AS closed,
               COALESCE(a.wins,0)   AS wins,
               COALESCE(a.total_pnl,0)::float AS total_pnl
        FROM v2_arm_defs d
        LEFT JOIN v2_arms a ON a.arm = d.arm
        WHERE d.alive = true
        ORDER BY d.kind, d.arm
        """
    )


def fitness(arm):
    closed = arm["closed"]
    live_exp = arm["total_pnl"] / closed if closed else None
    if arm["kind"] == "exit":
        if live_exp is None:
            return (None, "exit arm, no closed trades yet")
        return (live_exp, f"live exp {live_exp:+.1f} over {closed} trades")
    bt = score_genome(arm["params"] or {})
    bt_exp_pct = bt["expectancy"] * 100.0
    bt_ok = bt["n"] >= BT_MIN_N
    if live_exp is not None and bt_ok:
        blended = LIVE_WEIGHT * live_exp + (1 - LIVE_WEIGHT) * bt_exp_pct
        return (blended, f"blend live {live_exp:+.1f}({closed}) + bt {bt_exp_pct:+.1f}"
                         f"(n={bt['n']},cov={bt['coverage']}) = {blended:+.1f}")
    if live_exp is not None:
        return (live_exp, f"live exp {live_exp:+.1f} over {closed} trades (bt sample too small)")
    if bt_ok:
        return (bt_exp_pct, f"backtest only {bt_exp_pct:+.1f} (n={bt['n']},cov={bt['coverage']})")
    return (None, f"not enough data (closed={closed}, bt_n={bt['n']})")


def reap(scored):
    killed = []
    for kind in ("entry", "exit"):
        of_kind = [s for s in scored if s["kind"] == kind]
        alive_now = len(of_kind)
        of_kind_sorted = sorted(of_kind, key=lambda s: (s["score"] is None, s["score"]))
        best = max((s for s in of_kind if s["score"] is not None),
                   key=lambda s: s["score"], default=None)
        for s in of_kind_sorted:
            if alive_now <= MIN_ALIVE:
                break
            live_exp = s["total_pnl"] / s["closed"] if s["closed"] else None
            if s["closed"] < MIN_CLOSED or live_exp is None:
                continue
            if best and s["arm"] == best["arm"]:
                continue
            if live_exp < KILL_EXP:
                killed.append(s)
                alive_now -= 1
    return killed


def kill_arm(arm_name):
    db.execute("UPDATE v2_arm_defs SET alive=false, died_at=now() WHERE arm=%s", (arm_name,))
    db.execute("UPDATE v2_arms     SET alive=false, died_at=now() WHERE arm=%s", (arm_name,))


def _mutate(params):
    child = dict(params)
    for k, v in list(child.items()):
        if k not in PARAM_BOUNDS or not isinstance(v, (int, float)):
            continue
        lo, hi = PARAM_BOUNDS[k]
        nv = max(lo, min(hi, v * (1.0 + random.uniform(-0.30, 0.30))))
        child[k] = int(round(nv)) if k in INT_PARAMS else round(nv, 3)
    optional = ["min_buyers", "min_social_score", "max_top_holder", "min_comments"]
    if random.random() < 0.25:
        present = [o for o in optional if o in child]
        absent = [o for o in optional if o not in child]
        if random.random() < 0.5 and present:
            child.pop(random.choice(present))
        elif absent:
            add = random.choice(absent)
            lo, hi = PARAM_BOUNDS[add]
            val = random.uniform(lo, hi)
            child[add] = int(round(val)) if add in INT_PARAMS else round(val, 3)
    return child


def _child_name(parent_name):
    base = parent_name.split("-")[0]
    suffix = "".join(random.choices(string.ascii_lowercase + string.digits, k=4))
    return f"{base}g-{suffix}"


def breed(scored):
    born = []
    for kind in ("entry", "exit"):
        of_kind = [s for s in scored if s["kind"] == kind and s["score"] is not None]
        alive_now = len([s for s in scored if s["kind"] == kind])
        parents = [p for p in sorted(of_kind, key=lambda s: s["score"], reverse=True)
                   if p["score"] > BREED_MIN_EXP]
        i = 0
        while alive_now < MAX_ALIVE and parents:
            parent = parents[i % len(parents)]
            child = {"arm": _child_name(parent["arm"]), "kind": kind,
                     "params": _mutate(parent["params"] or {}),
                     "gen": (parent["gen"] or 1) + 1, "parent": parent["arm"]}
            born.append(child)
            alive_now += 1
            i += 1
            if i >= len(parents) * 3:
                break
    return born


def insert_child(child):
    import json
    db.execute(
        "INSERT INTO v2_arm_defs (arm, kind, params, gen, parent, alive, born_at) "
        "VALUES (%s,%s,%s,%s,%s,true,now())",
        (child["arm"], child["kind"], json.dumps(child["params"]),
         child["gen"], child["parent"]),
    )
    db.execute(
        "INSERT INTO v2_arms (arm, closed, wins, total_pnl, alive) "
        "VALUES (%s,0,0,0,true) ON CONFLICT (arm) DO NOTHING",
        (child["arm"],),
    )


def run_generation():
    mode = "DRY RUN (no writes)" if DRY_RUN else "LIVE (writing to Supabase)"
    _log(f"\n{'='*66}\n  EVOLUTION — {mode}\n{'='*66}")
    arms = load_arms()
    scored = []
    for a in arms:
        s, detail = fitness(a)
        a = dict(a); a["score"] = s; a["detail"] = detail
        scored.append(a)

    _log("\n  ARMS (fittest first per kind):")
    for kind in ("entry", "exit"):
        _log(f"\n   {kind.upper()}:")
        for s in sorted([s for s in scored if s["kind"] == kind],
                        key=lambda s: (s["score"] is None, -(s["score"] or 0))):
            sc = f"{s['score']:+.1f}" if s["score"] is not None else "  n/a"
            _log(f"     {sc:>7}  {s['arm']:<18} gen{s['gen']}  ({s['detail']})")

    killed = reap(scored)
    _log("\n  REAP (extinction of the feeble):")
    if not killed:
        _log("     nothing dies this round")
    for k in killed:
        _log(f"     KILL {k['arm']:<18} live exp {k['total_pnl']/k['closed']:+.1f} over {k['closed']} trades")
        if not DRY_RUN:
            kill_arm(k["arm"])

    killed_names = {k["arm"] for k in killed}
    survivors = [s for s in scored if s["arm"] not in killed_names]

    born = breed(survivors)
    _log("\n  BREED (mutated children of survivors):")
    if not born:
        _log("     no breeding this round")
    for c in born:
        _log(f"     BORN {c['arm']:<18} gen{c['gen']}  parent={c['parent']}  {c['params']}")
        if not DRY_RUN:
            insert_child(c)

    _log(f"\n  Summary: {len(scored)} alive -> {len(killed)} killed, {len(born)} born.\n")
    if not DRY_RUN:
        db.set_config("v2_evolver_beat", time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()))
    return {"alive": len(scored), "killed": len(killed), "born": len(born)}


if __name__ == "__main__":
    run_generation()
```

### `guardrails.py`
```python
"""
guardrails.py — WHAT THE BOT KNOWS ABOUT THE REAL WORLD.

  A) entry_allowed(coin) -> (ok, reason): hard rules vs honeypots/rugs/fake volume.
  B) risk_monitor(): portfolio circuit breaker; trips v2_trading_halted + Discord.

These are fixed laws evolution runs INSIDE; strategies can't override them.
"""

import os
import time
import json
import db

KNOWLEDGE = {
    "honeypot": "Freeze authority active or transfers blocked = may be unable to SELL.",
    "rug_pull": "Mint authority not renounced or LP not locked/burned = dev can pull floor.",
    "insider_dump": "Large dev buy / concentrated holders will dump on you.",
    "fake_volume": "Identical buys, volume with no sells, or dead socials = wash trading.",
    "slippage": "Real fills are far worse than quotes; never assume you sell the peak.",
    "capture": "Average peak multiple is NOT captured profit; sizing and stops matter most.",
}


def _cfg(key, default):
    v = db.get_config(key, None)
    return v if v is not None else default


def entry_allowed(coin):
    def g(*names, default=None):
        for n in names:
            if n in coin and coin[n] is not None:
                return coin[n]
        return default

    min_mcap = float(_cfg("min_mcap_usd", os.environ.get("MIN_MCAP_USD", 5000)))
    max_mcap = float(_cfg("max_mcap_usd", os.environ.get("MAX_MCAP_USD", 80000)))
    max_age  = float(_cfg("max_age_sec", os.environ.get("MAX_AGE_SEC", 3600)))
    require_link = str(_cfg("require_real_link", "1")) == "1"
    max_dev_sol = float(os.environ.get("MAX_DEV_BUY_SOL", 15))
    min_buyers  = int(os.environ.get("MIN_BUYERS", 5))
    max_top_holder = float(os.environ.get("MAX_TOP_HOLDER_PCT", 80))

    if g("freeze_active") is True:
        return (False, "HONEYPOT: freeze authority active")
    buys, sells = g("buys", default=0), g("sells")
    if sells is not None and buys and buys >= 15 and sells == 0:
        return (False, "HONEYPOT-LIKE: many buys, zero sells")
    if g("mint_renounced") is False:
        return (False, "RUG RISK: mint authority not renounced")
    if g("lp_locked") is False:
        return (False, "RUG RISK: liquidity not locked/burned")
    if g("mcap_suspect") is True or g("inflated") is True:
        return (False, "FAKE VOLUME: mcap flagged suspect/inflated")
    dev = g("dev_buy_sol", default=0) or 0
    if dev > max_dev_sol:
        return (False, f"INSIDER RISK: dev buy {dev} SOL > {max_dev_sol}")
    top = g("top_holder_pct")
    if top is not None and top > max_top_holder:
        return (False, f"CONCENTRATION: top holder {top}% > {max_top_holder}%")
    if require_link and not (g("twitter") or g("website") or g("telegram")):
        return (False, "NO REAL LINK")
    mcap = g("mcap_usd", "entry_mcap_usd", default=0) or 0
    if mcap < min_mcap:
        return (False, f"TOO SMALL: {mcap} < {min_mcap}")
    if mcap > max_mcap:
        return (False, f"TOO BIG: {mcap} > {max_mcap}")
    age = g("age_sec")
    if age is not None and age > max_age:
        return (False, f"TOO OLD: {age}s > {max_age}s")
    buyers = g("buyers")
    if buyers is not None and buyers < min_buyers:
        return (False, f"NO CROWD: {buyers} < {min_buyers}")
    return (True, "ok")


DAILY_LOSS_HALT = float(os.environ.get("DAILY_LOSS_HALT_PCT", 25))
DRAWDOWN_HALT   = float(os.environ.get("MAX_DRAWDOWN_HALT_PCT", 40))
CONSEC_LOSS_HALT = int(os.environ.get("CONSEC_LOSS_HALT", 8))


def _post_discord(msg):
    url = db.get_config("alpha_webhook") or db.get_config("conviction_webhook")
    if not url:
        return
    try:
        import urllib.request
        data = json.dumps({"content": msg}).encode()
        req = urllib.request.Request(url, data=data,
                                     headers={"Content-Type": "application/json"})
        urllib.request.urlopen(req, timeout=10)
    except Exception as e:
        print(f"[guardrails] discord alert failed: {e}")


def risk_monitor(dry_run=True):
    rows = db.query(
        """
        SELECT pnl_pct_real, pnl_pct, exited_at
        FROM v2_paper
        WHERE open = false AND exited_at IS NOT NULL
        ORDER BY exited_at DESC
        LIMIT 200
        """
    )

    def pnl(r):
        return r["pnl_pct_real"] if r["pnl_pct_real"] is not None else (r["pnl_pct"] or 0)

    today = time.strftime("%Y-%m-%d", time.gmtime())
    daily = sum(float(pnl(r)) for r in rows
                if r["exited_at"] and r["exited_at"].strftime("%Y-%m-%d") == today)
    streak = 0
    for r in rows:
        if float(pnl(r)) < 0:
            streak += 1
        else:
            break
    eq, peak, dd = 0.0, 0.0, 0.0
    for r in reversed(rows):
        eq += float(pnl(r)); peak = max(peak, eq); dd = min(dd, eq - peak)
    drawdown = -dd

    reasons = []
    if daily <= -DAILY_LOSS_HALT:
        reasons.append(f"daily loss {daily:.0f}% <= -{DAILY_LOSS_HALT:.0f}%")
    if drawdown >= DRAWDOWN_HALT:
        reasons.append(f"drawdown {drawdown:.0f}% >= {DRAWDOWN_HALT:.0f}%")
    if streak >= CONSEC_LOSS_HALT:
        reasons.append(f"{streak} losses in a row >= {CONSEC_LOSS_HALT}")

    state = {"daily_pnl": round(daily, 1), "drawdown": round(drawdown, 1),
             "streak": streak, "halt": bool(reasons), "reasons": reasons}
    if reasons and not dry_run:
        db.set_config("v2_trading_halted", "1")
        db.set_config("v2_halt_reason", "; ".join(reasons))
        _post_discord(f"TRADING HALTED by risk guardrail: {'; '.join(reasons)}")
    return state


if __name__ == "__main__":
    for k, v in KNOWLEDGE.items():
        print(f"  - {k}: {v}")
    print("\nRisk state (dry):", risk_monitor(dry_run=True))
```

### `arena.py`
```python
"""
arena.py — the always-on runner. Every cycle: check the portfolio circuit
breaker, then run one evolution generation. Loops forever.

  python arena.py          # loop (default every 60 min)
  python arena.py --once   # single generation, then exit
"""

import os
import sys
import time
import traceback
from dotenv import load_dotenv

from evolve import run_generation, DRY_RUN
from guardrails import risk_monitor

load_dotenv()

EVERY_MIN = int(os.environ.get("EVOLVE_EVERY_MIN", "60"))


def main():
    once = "--once" in sys.argv
    print(f"[arena] starting. cadence = every {EVERY_MIN} min. "
          f"{'single run' if once else 'looping'}")
    while True:
        try:
            state = risk_monitor(dry_run=DRY_RUN)
            flag = "HALT" if state["halt"] else "ok"
            print(f"[arena] risk: {flag}  daily={state['daily_pnl']}%  "
                  f"drawdown={state['drawdown']}%  streak={state['streak']}"
                  + (f"  reasons={state['reasons']}" if state["halt"] else ""))
            run_generation()
        except Exception:
            print("[arena] cycle failed:")
            traceback.print_exc()
        if once:
            break
        try:
            time.sleep(EVERY_MIN * 60)
        except KeyboardInterrupt:
            print("\n[arena] stopped.")
            break


if __name__ == "__main__":
    main()
```

### `requirements.txt`
```
psycopg2-binary==2.9.9
python-dotenv==1.0.1
```

### `Procfile`
```
worker: python arena.py
```

### `.gitignore`
```
.env
__pycache__/
*.pyc
```

### `.env.example`
```
DATABASE_URL=postgresql://postgres.cvicypryecnxvwqczgtg:YOUR-DB-PASSWORD@aws-0-ap-southeast-1.pooler.supabase.com:5432/postgres
DRY_RUN=1
EVOLVE_EVERY_MIN=60
MIN_CLOSED=8
KILL_EXP=-8
MIN_ALIVE=3
MAX_ALIVE=12
BREED_MIN_EXP=0
BT_MIN_N=15
LIVE_WEIGHT=0.6
```

---

## 4. RAILWAY BUILD NOTE

Railway (nixpacks) auto-detects Python from `requirements.txt` and runs the `worker` process from the `Procfile`. This is a **worker with no HTTP port** — do not add a domain or a healthcheck port. If nixpacks needs a Python version pin, add a `runtime.txt` containing `python-3.12`.

---

## 5. WHAT'S ALREADY DONE (do not repeat)

- ✅ Railway project `bigdog-arena` created (projectId `13659875-c684-409d-9ca7-23e0b0d9022d`, prod env `b80c5d75-25b5-4b9b-b6de-8b9b58da6ca4`).
- ✅ Variables `DATABASE_URL`, `DRY_RUN=1`, `EVOLVE_EVERY_MIN=60` set on that environment.
- ✅ Code validated against the live DB (the reap logic correctly identifies `E3-clean6k` and `T3-momentum` as the two kills).
- ❌ GitHub repo does not exist yet (the previous session's integration lacked repo-creation permission).
- ❌ Code not yet pushed / deployed.

---

## 6. YOUR STEPS (do these in order)

1. **Create the GitHub repo** `christianbooth91-spec/bigdog-arena` (private). If your integration also can't create repos, ask the owner to create it (github.com/new, add a README so `main` exists), then continue.
2. **Push all files** from section 3 to `main` in one commit. Confirm `.env` is NOT included and `.gitignore` IS.
3. **Confirm the Railway variables** exist on project `13659875-c684-409d-9ca7-23e0b0d9022d` / env `b80c5d75-25b5-4b9b-b6de-8b9b58da6ca4`. If missing, set: `DATABASE_URL` (section 2), `DRY_RUN=1`, `EVOLVE_EVERY_MIN=60`.
4. **Deploy from the repo** into that project (create a service from `christianbooth91-spec/bigdog-arena`, branch `main`). If the project is unreachable, create a new `bigdog-arena` project and set the vars first.
5. **Read the deploy logs.** Wait for the build to finish, then fetch runtime (`deploy`) logs. You are looking for the `EVOLUTION — DRY RUN` banner and an `ARMS` scoreboard. **Success = it connected to Supabase and printed a generation report with no traceback.**
6. **Verify the decision** in the logs: the DRY RUN should list `KILL E3-clean6k` and `KILL T3-momentum` (numbers will differ as live trades accrue) and `BORN` children under BREED. If instead you see a `psycopg2.OperationalError` / connection timeout, the DATABASE_URL is wrong — re-check the percent-encoding of the password.
7. **Report back to the owner**: paste the DRY RUN scoreboard + reap/breed summary from the logs, and confirm the worker is looping. **Do NOT flip DRY_RUN to 0 yet** — that is the owner's explicit go/no-go call (see section 7).

---

## 7. GOING LIVE (only when the owner says so)

When the owner has read the DRY RUN report and approves:
- Set Railway variable `DRY_RUN=0` and redeploy.
- From then on the worker actually kills feeble arms (`alive=false`, `died_at`) and inserts mutated children into `v2_arm_defs` / `v2_arms`, and updates the `v2_evolver_beat` heartbeat in `bot_config` each cycle.
- The owner's existing live worker should be told to honour the `v2_trading_halted` flag in `bot_config` (the circuit breaker sets it) — if it doesn't yet, add that check to that worker so a halt actually stops new entries.

---

## 8. TUNING KNOBS (Railway variables — safe defaults already set)

| Var | Default | Meaning |
|-----|---------|---------|
| `DRY_RUN` | 1 | 1 = simulate only; 0 = act |
| `EVOLVE_EVERY_MIN` | 60 | minutes between generations |
| `MIN_CLOSED` | 8 | trades before an arm can be judged/killed |
| `KILL_EXP` | -8 | avg live pnl/trade below this = death candidate |
| `MIN_ALIVE` | 3 | never drop a kind below this many alive |
| `MAX_ALIVE` | 12 | population cap per kind (breed up to this) |
| `BREED_MIN_EXP` | 0 | only breed arms fitter than this |
| `LIVE_WEIGHT` | 0.6 | entry fitness = 60% live + 40% backtest |
| `DAILY_LOSS_HALT_PCT` | 25 | daily loss that trips the halt |
| `MAX_DRAWDOWN_HALT_PCT` | 40 | drawdown that trips the halt |
| `CONSEC_LOSS_HALT` | 8 | losing streak that trips the halt |

---

## 9. HONEST CAVEATS (tell the owner, don't bury)

- Keep it in **paper mode** until evolved survivors show positive expectancy over a few hundred real trades. The engine's biggest value is killing losers before they cost real money, not printing profit on day one.
- Backtests only apply to **entry** arms and only for params that map to stored columns; low `coverage` = weak evidence. Live results are the real judge.
- `peak_x_usd` is a ceiling, not captured profit. The backtest models a realistic exit, but real slippage on pump.fun coins can still be worse.
- The graded+outcome sample is small; treat early "edges" (e.g. watched-creator launches) as hypotheses to test, not facts.

**END OF HANDOFF.**
