"""
guardrails.py — WHAT THE BOT KNOWS ABOUT THE REAL WORLD  (v2 — upgraded from live analysis).

Two jobs:
  A) entry_allowed(coin) -> (ok, reason): the hard rules a launch must pass before ANY
     strategy buys it. Now encodes the "runner vs dud" fingerprint we proved across
     three peak bands (6-10k duds vs 50k+ runners) plus the honeypot/rug/fake-volume laws.
  B) risk_monitor(): portfolio circuit breaker (trips v2_trading_halted + Discord).

WHAT THE ANALYSIS TAUGHT US (why these thresholds exist):
  * Top-holder concentration is the cleanest separator — runners ~47%, duds ~67%.
    Above ~70% a coin is whale-owned and capped. Rule: max_top_holder 55.
  * Crowd size at 6k is the fuel gauge — runners median 45 buyers (47% had 50+),
    duds median 33 (only 21% had 50+). Rule: min_buyers 40.
  * Buy pressure: runners buy/sell ~1.48, duds ~1.22, 36% of duds were <1. Rule: >=1.4.
  * TIME matters: runners cluster 10:00-13:00 Sydney (US prime evening); duds cluster
    14:00-17:00 Sydney (US dead hours). Rule: prefer the runner window.
  * Dev-pumped mirages: birth already >8k + big dev buy = fake/inflated peak (e.g. the
    "$19M" 37coin had a 59-SOL dev buy and 19 buyers). Rule: cap dev buy, reject high birth.
  * Social & news themes do NOT predict price — a 21M-view coin peaked at $9k. So we DON'T
    gate on followers; we only use social as a NEGATIVE filter (impersonation) + a tail flag.
  * Impersonation underperforms: verified+quote-tweet and "Official X" launches lagged.
"""

import os
import time
import json
from datetime import datetime, timezone, timedelta

import db

SYD = timezone(timedelta(hours=10))  # Australia/Sydney (AEST; ignores DST for simplicity)

KNOWLEDGE = {
    "concentration": "Top holder <55% = runner zone; >70% = whale-capped dud. Cleanest signal.",
    "crowd": "40+ unique buyers at 6k = real demand. The single best 'is anyone here' tell.",
    "pressure": "Buy/sell >=1.4 at 6k. Below 1 (more sells) = skip.",
    "timing": "Best 10:00-13:00 Sydney (US prime). Worst 14:00-17:00 Sydney (US dead hours).",
    "dev_pump": "Birth already >8k + big dev buy = inflated/wash peak you cannot really ride.",
    "social_noise": "Followers/views/likes do NOT predict price. Never size up on virality alone.",
    "impersonation": "Verified+quote-tweet and 'Official <celebrity>' launches underperform — skip.",
    "honeypot": "Freeze authority or blocked sells = you can't exit. Never enter.",
    "rug": "Mint not renounced or LP not locked = dev can pull the floor.",
    "capture": "Target a 2x (100% win when hit historically); let a runner ride the rest. Size small.",
}


def _cfg(key, default):
    v = db.get_config(key, None)
    return v if v is not None else default


def entry_time_ok(dt=None):
    """
    Sydney day+time gate. Returns (ok, hour, tier).
    Hours: 10:00-13:00 = prime (US prime evening); 18:00-19:00 = ok (US afternoon);
           14:00-17:00 = avoid (US dead hours = dud window).
    Days:  Sat/Sun are the worst trading days -> only the PRIME window is allowed on
           weekends. Mon-Fri trade prime+ok. Set WEEKEND_PRIME_ONLY=0 to relax.
    """
    if dt is None:
        return (True, None, "unknown")   # no timestamp -> don't block, just report
    syd = dt.astimezone(SYD)
    h, wd = syd.hour, syd.weekday()      # wd: 0=Mon .. 6=Sun
    weekend = wd >= 5
    weekend_prime_only = str(os.environ.get("WEEKEND_PRIME_ONLY", "1")) == "1"

    if 10 <= h <= 13:
        tier = "prime"
    elif h in (18, 19):
        tier = "ok"
    elif 14 <= h <= 17:
        tier = "avoid"
    else:
        tier = "ok"

    if weekend and weekend_prime_only and tier != "prime":
        return (False, h, f"weekend-{tier}")   # Sat/Sun: prime window only
    return (tier != "avoid", h, tier + ("-weekend" if weekend else ""))


def entry_allowed(coin, enforce_time=True):
    """
    coin: dict describing a launch. Missing keys are treated conservatively.
    Returns (ok, reason). ok=False = DO NOT BUY.
    Recognised keys: mcap_usd/entry_mcap_usd, birth_mcap, twitter, website, telegram,
      dev_buy_sol, buyers/unique_buyers, buys, sells, buy_sell_ratio, mcap_suspect, inflated,
      mint_renounced, freeze_active, lp_locked, top_holder_pct, age_sec, born_at (datetime),
      account_verified, account_blue_verified, is_quote, name, category.
    """
    def g(*names, default=None):
        for n in names:
            if n in coin and coin[n] is not None:
                return coin[n]
        return default

    # tunables (override via env)
    min_mcap  = float(_cfg("min_mcap_usd", os.environ.get("MIN_MCAP_USD", 5000)))
    max_mcap  = float(_cfg("max_mcap_usd", os.environ.get("MAX_MCAP_USD", 40000)))  # room to migration (~69k)
    max_age   = float(_cfg("max_age_sec", os.environ.get("MAX_AGE_SEC", 3600)))
    require_link   = str(_cfg("require_real_link", "1")) == "1"
    MAX_DEV        = float(os.environ.get("MAX_DEV_BUY_SOL", 8))
    MIN_BUYERS     = int(os.environ.get("MIN_BUYERS", 40))
    MAX_TOP_HOLDER = float(os.environ.get("MAX_TOP_HOLDER_PCT", 55))
    MIN_BS         = float(os.environ.get("MIN_BS_RATIO", 1.4))
    MAX_BIRTH      = float(os.environ.get("MAX_BIRTH_MCAP", 8000))  # above = likely dev-pumped

    # --- honeypot / rug (can we sell? is the floor real?) ---
    if g("freeze_active") is True:
        return (False, "HONEYPOT: freeze authority active")
    buys, sells = g("buys", default=0), g("sells")
    if sells is not None and buys and buys >= 15 and sells == 0:
        return (False, "HONEYPOT-LIKE: many buys, zero sells")
    if g("mint_renounced") is False:
        return (False, "RUG: mint authority not renounced")
    if g("lp_locked") is False:
        return (False, "RUG: liquidity not locked/burned")

    # --- fake volume / dev-pump mirage ---
    if g("mcap_suspect") is True or g("inflated") is True:
        return (False, "FAKE VOLUME: mcap flagged suspect/inflated")
    birth = g("birth_mcap")
    if birth is not None and birth > MAX_BIRTH:
        return (False, f"DEV-PUMP: birth mcap {birth:.0f} > {MAX_BIRTH:.0f} (started too high)")
    dev = g("dev_buy_sol", default=0) or 0
    if dev > MAX_DEV:
        return (False, f"DEV-PUMP: dev buy {dev} SOL > {MAX_DEV}")

    # --- impersonation (underperforms) ---
    name = (g("name", default="") or "").lower()
    if g("is_quote") is True and (g("account_verified") is True or g("account_blue_verified") is True):
        return (False, "IMPERSONATION-RISK: verified account quote-tweeting a launch")
    if name.startswith("official ") or "official taylor" in name:
        return (False, "IMPERSONATION-RISK: 'Official <celebrity>' launch")

    # --- THE RUNNER FINGERPRINT (concentration / crowd / pressure) ---
    top = g("top_holder_pct")
    if top is not None and top > MAX_TOP_HOLDER:
        return (False, f"CONCENTRATION: top holder {top}% > {MAX_TOP_HOLDER}% (whale-capped)")
    buyers = g("buyers", "unique_buyers")
    if buyers is not None and buyers < MIN_BUYERS:
        return (False, f"NO CROWD: {buyers} buyers < {MIN_BUYERS}")
    bs = g("buy_sell_ratio")
    if bs is not None and bs < MIN_BS:
        return (False, f"WEAK PRESSURE: buy/sell {bs} < {MIN_BS}")

    # --- timing ---
    if enforce_time:
        ok_t, hr, tier = entry_time_ok(g("born_at"))
        if not ok_t:
            return (False, f"BAD TIMING: {hr:02d}:00 Sydney (US dead hours = dud window)")

    # --- basic quality gates ---
    if require_link and not (g("twitter") or g("website") or g("telegram")):
        return (False, "NO REAL LINK")
    mcap = g("mcap_usd", "entry_mcap_usd", default=0) or 0
    if mcap < min_mcap:
        return (False, f"TOO SMALL: {mcap} < {min_mcap}")
    if mcap > max_mcap:
        return (False, f"TOO BIG: {mcap} > {max_mcap} (little room before migration)")
    age = g("age_sec")
    if age is not None and age > max_age:
        return (False, f"TOO OLD: {age}s > {max_age}s")

    # bonus flag (not a gate): animal category + genuine mega-KOL = size-up candidate
    bonus = []
    if g("category") == "animal":
        bonus.append("animal")
    foll = g("poster_followers", default=0) or 0
    if foll >= 100000:
        bonus.append("mega-KOL(tail)")
    tag = (" +" + "/".join(bonus)) if bonus else ""
    return (True, "ok" + tag)


# ----------------------------------------------------------------------------
# PORTFOLIO CIRCUIT BREAKER  (meme books swing hard -> wider than textbook)
# ----------------------------------------------------------------------------
DAILY_LOSS_HALT = float(os.environ.get("DAILY_LOSS_HALT_PCT", 25))
DRAWDOWN_HALT   = float(os.environ.get("MAX_DRAWDOWN_HALT_PCT", 40))
CONSEC_LOSS_HALT = int(os.environ.get("CONSEC_LOSS_HALT", 8))


def _post_discord(msg):
    url = db.get_config("alpha_webhook") or db.get_config("conviction_webhook")
    if not url:
        return
    try:
        import urllib.request
        data = json.dumps({"content": msg}).encode()
        req = urllib.request.Request(url, data=data, headers={"Content-Type": "application/json"})
        urllib.request.urlopen(req, timeout=10)
    except Exception as e:
        print(f"[guardrails] discord alert failed: {e}")


def risk_monitor(dry_run=True):
    # NOTE: column is pnl_pct_quoted in the live schema (was pnl_pct_real earlier).
    rows = db.query(
        """
        SELECT pnl_pct_quoted, pnl_pct, exited_at
        FROM v2_paper
        WHERE open = false AND exited_at IS NOT NULL
        ORDER BY exited_at DESC
        LIMIT 200
        """
    )

    def pnl(r):
        v = r.get("pnl_pct_quoted")
        return v if v is not None else (r.get("pnl_pct") or 0)

    today = time.strftime("%Y-%m-%d", time.gmtime())
    daily = sum(float(pnl(r)) for r in rows
                if r["exited_at"] and r["exited_at"].strftime("%Y-%m-%d") == today)
    streak = 0
    for r in rows:
        if float(pnl(r)) < 0:
            streak += 1
        else:
            break
    eq, peak, dd = 0.0, 0.0, 0.0
    for r in reversed(rows):
        eq += float(pnl(r)); peak = max(peak, eq); dd = min(dd, eq - peak)
    drawdown = -dd

    reasons = []
    if daily <= -DAILY_LOSS_HALT:
        reasons.append(f"daily loss {daily:.0f}% <= -{DAILY_LOSS_HALT:.0f}%")
    if drawdown >= DRAWDOWN_HALT:
        reasons.append(f"drawdown {drawdown:.0f}% >= {DRAWDOWN_HALT:.0f}%")
    if streak >= CONSEC_LOSS_HALT:
        reasons.append(f"{streak} losses in a row >= {CONSEC_LOSS_HALT}")

    state = {"daily_pnl": round(daily, 1), "drawdown": round(drawdown, 1),
             "streak": streak, "halt": bool(reasons), "reasons": reasons}
    if reasons and not dry_run:
        db.set_config("v2_trading_halted", "1")
        db.set_config("v2_halt_reason", "; ".join(reasons))
        _post_discord(f"TRADING HALTED by risk guardrail: {'; '.join(reasons)}")
    return state


if __name__ == "__main__":
    for k, v in KNOWLEDGE.items():
        print(f"  - {k}: {v}")
    # demo: a clean runner vs a dud
    runner = {"top_holder_pct": 47, "buyers": 55, "buy_sell_ratio": 1.6, "dev_buy_sol": 3,
              "birth_mcap": 3200, "mcap_usd": 6000, "twitter": "x", "category": "animal"}
    dud = {"top_holder_pct": 74, "buyers": 30, "buy_sell_ratio": 0.9, "dev_buy_sol": 3,
           "birth_mcap": 3300, "mcap_usd": 6000, "twitter": "x"}
    print("\nrunner ->", entry_allowed(runner, enforce_time=False))
    print("dud    ->", entry_allowed(dud, enforce_time=False))
