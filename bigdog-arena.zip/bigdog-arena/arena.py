"""
arena.py — the runner you leave going on your PC (bigdogpc).

It runs one evolution generation, then sleeps, forever. That's it. Your existing
pipeline keeps doing the live paper trading; this process just handles the
natural selection on top of it — killing losers and breeding winners on a
schedule.

RUN IT:
    python arena.py            # loop forever (default every 60 min)
    python arena.py --once     # run a single generation and exit
    EVOLVE_EVERY_MIN=30 python arena.py   # change the cadence

Stop it any time with Ctrl+C. Nothing is lost — state lives in Supabase.
Remember: it starts in DRY_RUN mode (writes nothing) until you set DRY_RUN=0
in your .env file.
"""

import os
import sys
import time
import traceback
from dotenv import load_dotenv

from evolve import run_generation, DRY_RUN
from guardrails import risk_monitor

load_dotenv()

EVERY_MIN = int(os.environ.get("EVOLVE_EVERY_MIN", "60"))


def main():
    once = "--once" in sys.argv
    print(f"[arena] starting. cadence = every {EVERY_MIN} min. "
          f"{'single run' if once else 'looping (Ctrl+C to stop)'}")
    while True:
        try:
            # 1) portfolio circuit breaker — checks the live book, can trip a halt
            state = risk_monitor(dry_run=DRY_RUN)
            flag = "🛑 HALT" if state["halt"] else "✅ ok"
            print(f"[arena] risk: {flag}  daily={state['daily_pnl']}%  "
                  f"drawdown={state['drawdown']}%  streak={state['streak']}"
                  + (f"  reasons={state['reasons']}" if state["halt"] else ""))
            # 2) evolution — score, reap, breed
            run_generation()
        except Exception:
            print("[arena] cycle failed:")
            traceback.print_exc()
        if once:
            break
        try:
            time.sleep(EVERY_MIN * 60)
        except KeyboardInterrupt:
            print("\n[arena] stopped.")
            break


if __name__ == "__main__":
    main()
