"""
v3_evolve.py — natural selection for the migration-zone (v3) arena.
Same principle as the v2 evolver: score live results, kill proven losers, breed
mutated children of winners. Conservative + DRY_RUN by default. Run periodically
(e.g. hourly) alongside v3_worker.py.
"""
import os, random, string, json, time
from dotenv import load_dotenv
import db
load_dotenv()

DRY_RUN = os.environ.get("DRY_RUN", "1") == "1"
MIN_CLOSED = int(os.environ.get("V3_MIN_CLOSED", "8"))
KILL_EXP   = float(os.environ.get("V3_KILL_EXP", "-8"))
MIN_ALIVE  = int(os.environ.get("V3_MIN_ALIVE", "2"))
MAX_ALIVE  = int(os.environ.get("V3_MAX_ALIVE", "8"))
BOUNDS = {"entry_level":(40000,55000),"max_top_holder":(35,65),"min_buyers":(20,100),
 "min_bs_ratio":(1.1,2.5),"max_dev":(2,12),"target":(1.2,2.0),"stop":(0.75,0.95),
 "timeout_min":(15,90),"activate":(1.1,1.6),"giveback":(0.15,0.4),"timeout_h":(2,12)}
INTS = {"entry_level","max_top_holder","min_buyers","max_dev","timeout_min"}


def load():
    return db.query("""SELECT d.arm,d.kind,d.params,d.gen,COALESCE(a.closed,0) closed,
        COALESCE(a.total_pnl,0)::float pnl FROM v3_arm_defs d JOIN v3_arms a ON a.arm=d.arm
        WHERE d.alive ORDER BY d.kind""")


def mutate(p):
    c = dict(p)
    for k, v in list(c.items()):
        if k in BOUNDS and isinstance(v, (int, float)):
            lo, hi = BOUNDS[k]; nv = max(lo, min(hi, v*(1+random.uniform(-0.25, 0.25))))
            c[k] = int(round(nv)) if k in INTS else round(nv, 3)
    return c


def run():
    arms = load()
    for a in arms:
        a["exp"] = a["pnl"]/a["closed"] if a["closed"] else None
    print(f"[v3-evolve] {'DRY' if DRY_RUN else 'LIVE'} — {len(arms)} alive")
    for kind in ("entry", "exit"):
        k = [a for a in arms if a["kind"] == kind]
        alive = len(k)
        best = max((a for a in k if a["exp"] is not None), key=lambda a: a["exp"], default=None)
        # reap
        for a in sorted([x for x in k if x["exp"] is not None], key=lambda a: a["exp"]):
            if alive <= MIN_ALIVE: break
            if a["closed"] >= MIN_CLOSED and a["exp"] < KILL_EXP and a["arm"] != (best or {}).get("arm"):
                print(f"[v3-evolve] KILL {a['arm']} exp {a['exp']:+.1f}/{a['closed']}")
                if not DRY_RUN:
                    db.execute("UPDATE v3_arm_defs SET alive=false,died_at=now() WHERE arm=%s", (a["arm"],))
                    db.execute("UPDATE v3_arms SET alive=false,died_at=now() WHERE arm=%s", (a["arm"],))
                alive -= 1
        # breed from best if room & proven
        if alive < MAX_ALIVE and best and best["closed"] >= 5 and best["exp"] > 0:
            child = best["arm"].split("-")[0] + "g-" + "".join(random.choices(string.ascii_lowercase+string.digits, k=4))
            cp = mutate(best["params"] or {})
            print(f"[v3-evolve] BREED {child} from {best['arm']} {cp}")
            if not DRY_RUN:
                db.execute("INSERT INTO v3_arm_defs(arm,kind,params,gen,parent) VALUES(%s,%s,%s,%s,%s) ON CONFLICT DO NOTHING",
                           (child, kind, json.dumps(cp), (best["gen"] or 1)+1, best["arm"]))
                db.execute("INSERT INTO v3_arms(arm) VALUES(%s) ON CONFLICT DO NOTHING", (child,))
    if not DRY_RUN:
        db.set_config("v3_evolver_beat", time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()))


if __name__ == "__main__":
    run()
